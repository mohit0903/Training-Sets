This Training set 2 was completed before HOLI ( 15/03/2020 ) in CP3
deque 1 is the modified version of deque in which left=8 and right=9