/* An implementation of Deque */
#include "deque1.h"
int co=0;
int data[SIZE];
int left = 8;
int right = 9;
void insertLeft(int d)
{
    if (size() == SIZE-1)
        return;
    data[left] = d;
    left = (left-1+SIZE)%SIZE;
    co++;

}
void insertRight(int d)
{
    if (size() == SIZE-1)
        return;
    data[right]=d;
    right=(right+1)%SIZE;
    co++;
}
int removeLeft()
{
    int d, s;
    s = size();
    if (s==0)
        return ERR_DATA; // Error value
    left=(left+1)%SIZE;
    d=data[left];
    if (s == 1)
        init();
    co--;
    return d;
}
int removeRight()
{
    int d, s;
    s = size();
    if (s==0)
        return ERR_DATA; // Error value
    right=(right-1+SIZE)%SIZE;
    d=data[right];
    if (s == 1)
        init();
    co--;
    return d;
}
int canWelcome()
{
    return size() < SIZE;
}
int isEmpty()
{
    return size() == 0;
}
void init()
{
    right=9;
    left=8;
}
int size()
{
if(right==(left+1)%SIZE)
    return 0;
return co;
}
