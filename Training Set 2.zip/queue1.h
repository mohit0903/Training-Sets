/*Header file for queue.c*/
#include "deque1.h"
void joinQ(int);
int leaveQ();

