/*Header file for queue.c*/
#include "deque.h"
void joinQ(int);
int leaveQ();
